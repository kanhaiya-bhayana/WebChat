<br><br><br><br><center>
<div style="width:400px;padding:10px;background:red;color:white;border-radius:10px;font-family:arial;font-size:12pt" align="center">
    We have sended you a account activation link on your registered email address. Please confirm and login.
    <br>
    <p>Thanks From, <br><br><br> <b>Team Cyber Chatter</b></p>
</div>
</center>