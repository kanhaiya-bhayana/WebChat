<?php

$userid=$_GET['user'];
 header('location:refresh.php?user='.$userk."#ok");
 ?>
