    <?php

$cn=mysqli_connect('localhost','cyberbyk_okcyber','divyanshu098','cyberbyk_divyanshu876');
?>
